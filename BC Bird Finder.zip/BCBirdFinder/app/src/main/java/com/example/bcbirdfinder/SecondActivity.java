package com.example.bcbirdfinder;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    //create objects of each widget in activty_second.xml
    ImageView mainImageView;

    TextView titleTextView, scienceTextView, descriptionTextView, counterTextView;

    String data1, data2, data3;

    int myImage;

    Button birdButton;

    int birdCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        mainImageView = findViewById(R.id.imageView);

        titleTextView = findViewById(R.id.nameTextView);

        scienceTextView = findViewById(R.id.scienceTextView);

        descriptionTextView = findViewById(R.id.descriptionTextView);

        birdButton = findViewById(R.id.button);

        counterTextView = findViewById(R.id.counterTextView);

        //bird counter button onclick listener
        birdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                birdCount++;

                counterTextView.setText(birdCount+"");

            }
        });

        //call get and sets
        getData();

        setData();

    }

    //check if data exists in myadapter inner class view holder intent object
    private void getData(){

        if(getIntent().hasExtra("largeImageArray") && getIntent().hasExtra(
                "data1") && getIntent().hasExtra("data2") && getIntent().hasExtra("data3")){

            //if data exists it is stored in these temp variables
            data1 = getIntent().getStringExtra("data1");
            data2 = getIntent().getStringExtra("data2");
            data3 = getIntent().getStringExtra("data3");




            myImage = getIntent().getIntExtra("largeImageArray",1);


        } else { // if data doesn't exist a toast will be made

            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();

        }

    }

    private void setData(){

        //set data in new activity

        //title
        titleTextView.setText(data1);

        //science title
        scienceTextView.setText(data2);

        //description
        descriptionTextView.setText(data3);

        //set image
        mainImageView.setImageResource(myImage);

    }

}
