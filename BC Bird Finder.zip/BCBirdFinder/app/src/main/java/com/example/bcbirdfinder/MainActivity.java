package com.example.bcbirdfinder;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    //arrays to contain data
    String s1[], s2[], s3[];

    //this array will store the images for the main activity
    int regularImagesArray[] = {R.drawable.american_robin,
            R.drawable.black_capped_chickadee,
            R.drawable.common_starling,
            R.drawable.house_sparrow,
            R.drawable.northern_flicker,
            R.drawable.northwestern_crow,
            R.drawable.stellers_jay,
            R.drawable.violet_green_swallow,
            R.drawable.western_meadowlark};

    //the larger images
    int largeImagesArray[] = {R.drawable.american_robin_large,
            R.drawable.black_capped_chickadee_large,
            R.drawable.common_starling_large,
            R.drawable.house_sparrow_large,
            R.drawable.northern_flicker_large,
            R.drawable.northwestern_crow_large,
            R.drawable.stellers_jay_large,
            R.drawable.violet_green_swallow_large,
            R.drawable.western_meadowlark_large};


    //recyler view object
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initalize recycler view
        recyclerView = findViewById(R.id.recyclerView);

        //get string arrays from strings.xml
        s1 = getResources().getStringArray(R.array.birdNames);
        s2 = getResources().getStringArray(R.array.scienceBirdNames);
        s3 = getResources().getStringArray(R.array.birdDescriptions);

        //intialize my adapter and sent data to its constructor
        MyAdapter myAdapter = new MyAdapter(this,s1,s2,s3, regularImagesArray, largeImagesArray);

        recyclerView.setAdapter(myAdapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}
